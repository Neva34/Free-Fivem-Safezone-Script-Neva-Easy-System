fx_version 'cerulean'
game 'gta5'

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/style.css',
    'ui/script.js',
    'zones.json'
}

client_scripts { 'client.lua' }
server_scripts { 'server.lua' }