let currentAutoCoords = "";

window.addEventListener('message', function(event) {
    if (event.data.type === "openCreator") {
        const el = document.getElementById('creator-container');
        el.classList.remove('hidden');
        void el.offsetWidth;
        el.classList.add('active');
        
        currentAutoCoords = event.data.coords;
        const coordsInput = document.getElementById('coords');
        const modeToggle = document.getElementById('coordModeToggle');
        
        modeToggle.checked = false;
        document.getElementById('coordModeText').innerText = "Oto";
        coordsInput.value = currentAutoCoords;
        coordsInput.readOnly = true;
        coordsInput.parentElement.classList.add('readonly-input');
        document.getElementById('coordLockIcon').classList.replace('fa-pen', 'fa-lock');
        
        updateBlipVisibility();
    } else if (event.data.type === "uiStatus") {
        const el = document.getElementById('safezone-notification');
        if (event.data.active) {
            el.classList.remove('hidden');
            void el.offsetWidth;
            el.classList.add('active');
        } else {
            el.classList.remove('active');
            setTimeout(() => {
                if (!el.classList.contains('active')) {
                    el.classList.add('hidden');
                }
            }, 500);
        }
    }
});

document.getElementById('coordModeToggle').addEventListener('change', function(e) {
    const isManual = e.target.checked;
    const coordsInput = document.getElementById('coords');
    const lockIcon = document.getElementById('coordLockIcon');
    const modeText = document.getElementById('coordModeText');
    const wrapper = document.getElementById('coordInputWrapper');

    if (isManual) {
        modeText.innerText = "Manuel";
        coordsInput.readOnly = false;
        wrapper.classList.remove('readonly-input');
        lockIcon.classList.replace('fa-lock', 'fa-pen');
        
        let match = currentAutoCoords.match(/vector3\(([^,]+),\s*([^,]+),\s*([^)]+)\)/);
        if (match) {
            coordsInput.value = `${match[1]}, ${match[2]}, ${match[3]}`;
        }
    } else {
        modeText.innerText = "Oto";
        coordsInput.readOnly = true;
        wrapper.classList.add('readonly-input');
        lockIcon.classList.replace('fa-pen', 'fa-lock');
        coordsInput.value = currentAutoCoords;
    }
});

document.querySelectorAll('.custom-dropdown').forEach(dropdown => {
    const selected = dropdown.querySelector('.dropdown-selected');
    const list = dropdown.querySelector('.dropdown-list');
    const hiddenInput = dropdown.querySelector('input[type="hidden"]');
    const selectedText = dropdown.querySelector('.selected-text');

    selected.addEventListener('click', () => {
        document.querySelectorAll('.custom-dropdown').forEach(d => {
            if (d !== dropdown) d.classList.remove('open');
        });
        dropdown.classList.toggle('open');
    });

    list.querySelectorAll('li').forEach(item => {
        item.addEventListener('click', () => {
            selectedText.innerText = item.innerText;
            hiddenInput.value = item.getAttribute('data-value');
            
            list.querySelectorAll('li').forEach(li => li.classList.remove('active'));
            item.classList.add('active');
            
            dropdown.classList.remove('open');
            
            if (hiddenInput.id === 'showBlip') {
                updateBlipVisibility();
            }
        });
    });
});

document.addEventListener('click', function(e) {
    if (!e.target.closest('.custom-dropdown')) {
        document.querySelectorAll('.custom-dropdown').forEach(d => d.classList.remove('open'));
    }
});

function updateBlipVisibility() {
    const showBlipVal = document.getElementById('showBlip').value;
    const colorGroup = document.getElementById('blipColorGroup');
    if (showBlipVal === '1') {
        colorGroup.classList.add('hidden-group');
    } else {
        colorGroup.classList.remove('hidden-group');
    }
}

function parseCoordinates(coordStr) {
    let match = coordStr.match(/vector3\(([^,]+),\s*([^,]+),\s*([^)]+)\)/);
    if (match) {
        return { x: parseFloat(match[1]), y: parseFloat(match[2]), z: parseFloat(match[3]) };
    }
    let parts = coordStr.split(',').map(s => parseFloat(s.trim()));
    if (parts.length >= 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
        return { x: parts[0], y: parts[1], z: parts[2] };
    }
    return null;
}

function save() {
    const rawCoords = document.getElementById('coords').value;
    const parsedCoords = parseCoordinates(rawCoords);
    
    if (!parsedCoords) {
        return;
    }

    const data = {
        coords: parsedCoords,
        radius: parseFloat(document.getElementById('scale').value),
        showBlip: parseInt(document.getElementById('showBlip').value),
        color: parseInt(document.getElementById('blipColor').value)
    };
    
    fetch(`https://${GetParentResourceName()}/saveZone`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8'
        },
        body: JSON.stringify(data)
    });
    closeMenu();
}

function closeMenu() {
    const el = document.getElementById('creator-container');
    el.classList.remove('active');
    setTimeout(() => {
        if (!el.classList.contains('active')) {
            el.classList.add('hidden');
        }
    }, 500);
    fetch(`https://${GetParentResourceName()}/closeUI`, { method: 'POST' });
}