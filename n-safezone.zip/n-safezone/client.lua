local QBCore = exports['qb-core']:GetCoreObject()
local safeZones = {}
local currentBlips = {}
local isInside = false
local PlayerJob = {}

local WhitelistJobs = {
    "police",
    "ambulance"
}

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    PlayerJob = QBCore.Functions.GetPlayerData().job
end)

RegisterNetEvent('QBCore:Client:OnJobUpdate', function(JobInfo)
    PlayerJob = JobInfo
end)

AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        PlayerJob = QBCore.Functions.GetPlayerData().job
    end
end)

function refreshSafezones(data)
    safeZones = data
    for _, blip in pairs(currentBlips) do RemoveBlip(blip) end
    currentBlips = {}

    for _, zone in pairs(safeZones) do
        if zone.showBlip == 0 then
            local blip = AddBlipForRadius(zone.x, zone.y, zone.z, zone.radius + 0.0)
            SetBlipHighDetail(blip, true)
            SetBlipColour(blip, zone.color)
            SetBlipAlpha(blip, 128)
            table.insert(currentBlips, blip)
        end
    end
end

RegisterNetEvent('safezone:sync')
AddEventHandler('safezone:sync', function(zones)
    refreshSafezones(zones)
end)

RegisterCommand('safezone', function()
    local pCoords = GetEntityCoords(PlayerPedId())
    SetNuiFocus(true, true)
    
    local vectorFormat = string.format("vector3(%.2f, %.2f, %.2f)", pCoords.x, pCoords.y, pCoords.z)
    
    SendNUIMessage({
        type = "openCreator",
        coords = vectorFormat
    })
end)

RegisterNUICallback('saveZone', function(data, cb)
    local finalCoords = vector3(data.coords.x, data.coords.y, data.coords.z)
    TriggerServerEvent('safezone:server:save', finalCoords, data.radius, data.showBlip, data.color)
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNUICallback('closeUI', function(data, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

Citizen.CreateThread(function()
    while true do
        local sleep = 1000
        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)
        local found = false
        local isWhitelisted = false
        if PlayerJob and PlayerJob.name then
            for _, job in ipairs(WhitelistJobs) do
                if PlayerJob.name == job then
                    isWhitelisted = true
                    break
                end
            end
        end

        for _, zone in pairs(safeZones) do
            if #(coords - vector3(zone.x, zone.y, zone.z)) < zone.radius then
                found = true
                break
            end
        end

        if found then
            sleep = 0
            if not isInside then
                isInside = true
                SendNUIMessage({type = "uiStatus", active = true})
                if not isWhitelisted then
                    SetCurrentPedWeapon(playerPed, GetHashKey("WEAPON_UNARMED"), true)
                end
                SetLocalPlayerAsGhost(true)
            end
            
            SetEntityInvincible(playerPed, true)
            SetPlayerInvincible(PlayerId(), true)
            ClearPedBloodDamage(playerPed)
            ResetPedVisibleDamage(playerPed)
            ClearPedLastWeaponDamage(playerPed)
            
            if not isWhitelisted then
                DisablePlayerFiring(PlayerId(), true)
                DisableControlAction(0, 24, true) 
                DisableControlAction(0, 25, true) 
                DisableControlAction(0, 37, true)
                DisableControlAction(0, 47, true) 
                DisableControlAction(0, 58, true) 
                DisableControlAction(0, 140, true) 
                DisableControlAction(0, 141, true)
                DisableControlAction(0, 142, true) 
                DisableControlAction(0, 143, true) 
                DisableControlAction(0, 263, true) 
                DisableControlAction(0, 264, true) 
                DisableControlAction(0, 257, true) 
                SetPlayerCanDoDriveBy(playerPed, false)
            end
            
            local vehicles = GetGamePool('CVehicle')
            local myVeh = GetVehiclePedIsIn(playerPed, false)
            for _, veh in ipairs(vehicles) do
                if veh ~= myVeh then
                    SetEntityNoCollisionEntity(playerPed, veh, true)
                    SetEntityNoCollisionEntity(veh, playerPed, true)
                    if myVeh ~= 0 then
                        SetEntityNoCollisionEntity(myVeh, veh, true)
                        SetEntityNoCollisionEntity(veh, myVeh, true)
                    end
                end
            end
            
            if not isWhitelisted then
                if GetSelectedPedWeapon(playerPed) ~= GetHashKey("WEAPON_UNARMED") then
                    SetCurrentPedWeapon(playerPed, GetHashKey("WEAPON_UNARMED"), true)
                end
            end
        else
            if isInside then
                isInside = false
                SendNUIMessage({type = "uiStatus", active = false})
                SetEntityInvincible(playerPed, false)
                SetPlayerInvincible(PlayerId(), false)
                SetLocalPlayerAsGhost(false)
            end
        end
        Citizen.Wait(sleep)
    end
end)