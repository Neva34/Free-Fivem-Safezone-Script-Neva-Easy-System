local safeZones = {}

Citizen.CreateThread(function()
    local file = LoadResourceFile(GetCurrentResourceName(), "zones.json")
    if file then
        safeZones = json.decode(file) or {}
    end
end)

RegisterNetEvent('safezone:server:save')
AddEventHandler('safezone:server:save', function(coords, radius, showBlip, color)
    local newZone = {
        x = coords.x, 
        y = coords.y, 
        z = coords.z, 
        radius = radius, 
        showBlip = showBlip, 
        color = color
    }
    table.insert(safeZones, newZone)
    
    SaveResourceFile(GetCurrentResourceName(), "zones.json", json.encode(safeZones, {indent = true}), -1)
    TriggerClientEvent('safezone:sync', -1, safeZones)
end)

AddEventHandler('playerJoining', function()
    local src = source
    Citizen.Wait(2000)
    TriggerClientEvent('safezone:sync', src, safeZones)
end)